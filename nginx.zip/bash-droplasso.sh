#!/bin/bash
# A Nginx Shell Script To Block Spamhaus Lasso Drop Spam IP Address
# Run this script once a day and drop all spam network IPs (netblock) with http 403 client error.
# The script will get executed every day via /etc/cron.daily (make sure crond
# is running).
# -------------------------------------------------------------------------
# Copyright (c) 2008 nixCraft project <http://cyberciti.biz/fb/>
# This script is licensed under GNU GPL version 2.0 or above
# -------------------------------------------------------------------------
# This script is part of nixCraft shell script collection (NSSC)
# Visit http://bash.cyberciti.biz/ for more information.
# -------------------------------------------------------------------------
# Last updated on Jan/11/2010
# -------------------------------------------------------------------------
# reload command for nginx (SET THIS PATH) 
NGINX="/usr/sbin/nginx -s reload"
 
# tmp file for lasso 
FILE="/tmp/drop.lasso.txt.$$"
 
# nginx config file - path to nginx drop conf file (SET THIS PATH)
OUT="/etc/nginx/conf.d/drop.lasso.conf"
 
URL="https://www.spamhaus.org/drop/drop.txt"
 
# remove old file
[[ -f "$FILE" ]] && /bin/rm -f "$FILE"
 
# emply nginx deny file
echo -n ""> $OUT
 
# get database
wget --output-document="$FILE" "$URL"
 
# format in nginx deny netblock; format
grep -E -v '^;' "$FILE"  | awk '{ print "deny " $1";"}' >>"$OUT"
 
# reload nginx
sync && ${NGINX}