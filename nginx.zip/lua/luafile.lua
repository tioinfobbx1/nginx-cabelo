-- scp -P 44200 lua-firewall.lua root@111.90.151.153:/etc/nginx/lua/luafile.lua
-- tail -f /var/log/nginx/error.log| awk -v FS="(User-Agent|host)" '{print $2}'
-- tail -f /var/log/nginx/access.log | awk -v FS="(.com\"|HTTP)" '{print $2}'
-- local json = require("json")

--
local listaAddr = {
    'datapacket', 'wsoleads', 'zare.com',
    'amazonaws.com',
    'cache.google.com',
    'above', 'google', 'softlayer', 'amazonaws', 
    'cyveillance', 'phishtank', 'dreamhost', 
    'netpilot', 'calyxinstitute', 'tor-exit', 
    'msnbot', 'p3pwgdsn', 'netcraft', 'trendmicro', 
    'ebay', 'paypal', 'torservers', 'messagelabs', 
    'sucuri.net', 'crawler', 'duckduck', 'feedfetcher',
    'BitDefender', 'mcafee', 'antivirus', 'cloudflare', 
    'p3pwgdsn', 'avg', 'avira', 'avast', 'ovh.net', 
    'security', 'twitter', 'bitdefender', 'virustotal', 
    'phising', 'clamav', 'baidu', 'safebrowsing', 'eset', 
    'mailshell', 'azure', 'miniature', 'tlh.ro', 'aruba', 
    'dyn.plus.net', 'pagepeeker', 'SPRO-NET-207-70-0', 
    'SPRO-NET-209-19-128', 'vultr', 'colocrossing.com', 
    'geosr', 'drweb', 'dr.web', 'linode.com', 'opendns', 
    'cymru.com', 'sl-reverse.com', 'surriel.com', 'hosting', 
    'orange-labs', 'speedtravel', 'metauri', 'apple.com', 
    'bruuk.sk', 'sysms.net', 'oracle', 'cisco', 'amuri.net', 
    'versanet.de', 'hilfe-veripayed.com', 'googlebot.com', 
    'upcloud.host', 'nodemeter.net', 'e-active.nl', 'downnotifier', 
    'online-domain-tools', 'fetcher6-2.go.mail.ru', 
    'monitis.com', 'colocrossing.com', 'majestic12', 'as9105.com', 
    'btcentralplus.com', 'anonymizing-proxy', 'digitalcourage.de', 
    'triolan.net', 'staircaseirony', 'stelkom.net', 'comrise.ru', 
    'kyivstar.net', 'mpdedicated.com', 'starnet.md', 'progtech.ru', 
    'hinet.net', 'is74.ru', 'shore.net', 'cyberinfo', 'ipredator', 
    'unknown.telecom.gomel.by', 'minsktelecom.by', 'parked.factioninc.com'
  }
  
  --
  local listaAsn = {
      'AVAST', 'RIPE NETWORK COORDINATION', 'ORACLE CORPORATION', 'MICROSOFT', 'GHANA TELECOM',
      'M247 LTD', 'CORPORACION NACIONAL', 'DATACAMP LIMITED'
  }
  
  -- Get Curl
  local function get(url) 
    local handle = io.popen("curl -q -k -s -m 1 " .. url) 
    local result = handle:read("*a") 
    handle:close() 
    return result 
  end
  
  --local resultblackbox = get("https://blackbox.ipinfo.app/lookup/" .. ngx.var.remote_addr);
  --if (resultblackbox == 'Y') then
  --  blockIP('BlackBox')
  --  ngx.log(ngx.CRIT,"BlackBox: " .. resultblackbox)
  --end
  
  local function GetIPType(ip)
    local R = {ERROR = 0, IPV4 = 1, IPV6 = 2, STRING = 3}
  
    -- Check if the input is a string
    if type(ip) ~= "string" then
      return R.ERROR
    end
  
    -- Check for IPv4 format
    local chunks = {ip:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")}
    if #chunks == 4 then
      for _,v in ipairs(chunks) do
        if tonumber(v) > 255 then
          return R.STRING
        end
      end
      return R.IPV4
    end
  
    -- Check for IPv6 format
    local chunks = {ip:match("^"..(("([a-fA-F0-9]*):"):rep(8):gsub(":$","$")))}
    if #chunks == 8 or (#chunks < 8 and ip:match('::') and not ip:gsub("::","",1):match('::')) then
      for _,v in ipairs(chunks) do
        if #v > 0 and tonumber(v, 16) > 65535 then
          return R.STRING
        end
      end
      return R.IPV6
    end
  
    -- Return STRING if input doesn't match IPv4 or IPv6 formats
    return R.STRING
  end
  
  -- Resolve hostname for an IP address
  local function resolverIp(ip)
    local cmd = "host " .. ip
    local file = io.popen(cmd, 'r')
    if not file then
      return nil, "Failed to execute command: " .. cmd
    end
    local output = file:read('*all')
    file:close()
    if not output then
      return nil, "No output from command: " .. cmd
    end
    -- Extract the hostname from the output
    local hostname = output:match("pointer%s+(%S+)")
    if not hostname then
      return nil, "Failed to extract hostname from output: " .. output
    end
    return hostname
  end
  
  -- Resolve ASN for an IP address
  local function resolverAsn(ip)
    local cmd = "as-lookup " .. ip
    local file = io.popen(cmd, 'r')
    if not file then
      return nil, "Failed to execute command: " .. cmd
    end
    local output = file:read('*all')
    file:close()
    if not output then
      return nil, "No output from command: " .. cmd
    end
    -- Extract the ASN from the output
    local asn = output:match("^%d+")
    if not asn then
      return nil, "Failed to extract ASN from output: " .. output
    end
    return asn
  end
  
  
  --
  if (GetIPType(ngx.var.remote_addr) == 1) then
    --local hostname = resolverIp(ngx.var.remote_addr)
  
  --  for key, val in pairs(listaAddr) do
    --  if (hostname:match(val)) then
      --  blockIP('Host ADDR Block ' .. hostname)
    --  end
  --  end
  
    --
    --local asnname = resolverAsn(ngx.var.remote_addr)
    --ngx.log(ngx.CRIT, "Host ASN => " .. asnname)
  
    --for key, val in pairs(listaAsn) do
      --if (asnname:match(val)) then
        --blockIP('Host ASN Block ' .. val)
      --end
    --end
  end
  
  --
  --if (GetIPType(ngx.var.remote_addr) == 2) then
  --   ngx.log(ngx.CRIT, "Host IPV6 => " .. ngx.var.remote_addr)
  --end
  
  --
  local function getval(v, def)
    if v == nil then
       return def
    end
    return v
  end
  
  -- Gera Bloqueio no NGINX
  function blockIP (tipo)
    ngx.log(ngx.CRIT, "Cliente Bloqueado: " .. ngx.var.remote_addr .. " => " .. tipo);
  
    local file, err = io.open("/etc/nginx/blockips.conf", "a")
    if file == nil then
      ngx.log(ngx.CRIT,"Couldn't open file: " .. err)
    else
      file:write("deny " .. ngx.var.remote_addr, "; #" .. tipo .. "\n")
      file:close()
    end
  
    -- Add this block to immediately terminate the request with "403 Forbidden" status code
    return ngx.exit(ngx.HTTP_FORBIDDEN)
  end
  
  -- strpost php
  local function strpos (haystack, needle, offset) 
    local pattern = string.format("(%s)", needle)
    local i = string.find (haystack, pattern, (offset or 0))
    
    return (i ~= nil and i or false)
  end
  
  -- local Header
  local h = ngx.req.get_headers()
  
  -- Verifica user Agent
  if h["User-Agent"] == nil or h["User-Agent"] == '' then
    blockIP('User-Agent NULL')
  elseif (string.len(h["User-Agent"]) <= 10) then
    blockIP('User-Agent <10 ' .. h["User-Agent"])
  end
  
  -- METHOD: HEAD, TRACE
  --if (ngx.var.request_method == 'HEAD') or (ngx.var.request_method == 'TRACE') then
  --  blockIP('HEAD_TRACE')
  --end
  
  -- Navegadores bloqueados
  local listaBrowser = {
    'NetcraftSurveyAgent',
    'mattermost',
    'GRequests',
    'Go.http.client',
    'okhttp',
    'akka.http',
    'Spider.Bot',
    'axios',
    'bitdiscovery',
    'Ubuntu; Linux',
    'Pandalytics',
    'curl',
    'python.requests',
    'python',
    'OpenBSD i386',
    'ZoominfoBot',
    'ips.agent',
    'Palo Alto',
    'paloaltonetworks',
    'Apache.HttpClient',
    'proximic',
    'developers.google.com',
    'Linux x86_64',
    'Google.Test',
    'X11; Linux'
  }
  
  for key, val in pairs(listaBrowser) do
    if (h["User-Agent"]:match(val)) then
      blockIP('User-Agent Block ' .. h["User-Agent"])
    end
  end
  
  -- Lista de Arquivos Bloqueio
  local listaArquivos = {
    'wp-login.php',
    '.env',
    'wp-admin',
    'system_api.php',
    'rtmp.php',
    'health-check',
    'css.php',
    'phpunit.xsd',
    'browse.php',
    'GponForm',
    'gpon80',
    'wlwmanifest.xml',
    'wp-content',
    'setup.cgi'
  }
  
  for key, val in pairs(listaArquivos) do
    if (ngx.var.uri:match(val)) then
      blockIP('File Block ' .. ngx.var.uri)
    end
  end
  
  -- Bloqueio de Dominios
  local listaDominios = {
    'xcrojectgmb.live',
    'andardprofi.live',
    'wiefirmae.live',
    'lkiffeepro.live',
    'mfabletos.live',
    'sxfficience.live',
    'heckmarxfi.live',
  }
  
  for key, val in pairs(listaDominios) do
    if (ngx.var.host:match(val)) then
      blockIP('Host Block ' .. ngx.var.host)
    end
  end
  
  -- cf-ipcountry'), ['BR', 'IE', 'US', 'CA', 'PT']
  local listaCountry = {
          'CN', 'JP', 'DE', 'CZ', 'GB', 'KR', 'ZA', 'BO', 'SI',
          'TR', 'SG', 'LT', 'HR', 'BA', 'AT', 'SE', 'MD', 'CO',
          'AU', 'RU', 'NZ', 'NG', 'IT', 'BG', 'GT', 'CL', 'VN',
          'PA', 'IN', 'TH', 'NE', 'BB', 'LA', 'MZ', 'SN', 'TZ',
          'SL', 'BY', 'NO', 'HK', 'GN', 'PH', 'VU', 'HU', 'PE',
          'ID', 'PL', 'DO', 'TW', 'UZ', 'KZ', 'AZ', 'AO', 'MP',
          'TJ', 'UY', 'IL', 'GF', 'MQ', 'ST', 'SR', 'BD', 'LB',
          'SK', 'RS', 'TN', 'OM', 'IR', 'MY', 'CH', 'FI', 'T1',
          'AL', 'EG', 'QA', 'RO', 'UA', 'CI', 'PK', 'MA', 'SV',
          'LY', 'SV', 'SO', 'CR', 'LK', 'NP', 'YE', 'DZ', 'IQ',
          'PR', 'JO', 'MM', 'NI', 'AF', 'DK', 'CM', 'SA', 'SY',
          'HN', 'EC', 'SD', 'GA', 'PS', 'IS', 'HT', 'AE', 'BE',
          'MT', 'MC', 'NL', 'ME', 'IE', 'US', 'CA', 'EE', 'AM',
          'GR', 'LU', 'IM', 'BM', 'LI', 'GY', 'AD', 'KG', 'FR',
  }
  
  if h["cf-ipcountry"] == nil or h["cf-ipcountry"] == '' then
    --
  else
    for key, val in pairs(listaCountry) do
      if (h["cf-ipcountry"]:match(val)) then
  --      blockIP('Country Block ' .. h["cf-ipcountry"])
      end
    end
  end
  
  -- Bloqueio de REFFER
  --http://click2click.xyz
  --http://kanshy.best/
  
  -- CRIANDO ARRAY
  local data = {request={}, response={}}
  
  -- ARRAY KEYS
  local req = data["request"]
  -- local resp = data["response"]
  
  -- REQUEST ARRAY
  req["host"] = ngx.var.host
  req["uri"] = ngx.var.uri
  req["User-Agent"] = h["User-Agent"]
  req["Country"] = h["cf-ipcountry"]
  -- req["headers"] = ngx.req.get_headers()
  -- req["time"] = ngx.req.start_time()
  -- req["method"] = ngx.req.get_method()
  -- req["get_args"] = ngx.req.get_uri_args()
  -- req["post_args"] = ngx.req.get_post_args()
  -- req["body"] = ngx.var.request_body
  
  -- content_type = getval(ngx.var.CONTENT_TYPE, "")
  
  -- Response ARRAY
  -- resp["headers"] = ngx.resp.get_headers()
  -- resp["status"] = ngx.status
  -- resp["duration"] = ngx.var.upstream_response_time
  -- resp["time"] = ngx.now()
  -- resp["body"] = ngx.var.response_body
  
  -- ngx.log(ngx.CRIT, json.encode(data));
  